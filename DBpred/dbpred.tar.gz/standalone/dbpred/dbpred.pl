#!/gpsr/local/bin/perl 

use Getopt::Std;
getopts('i:t:m:o:');

$ifile=$opt_i;
$thr=$opt_t;
$method=$opt_m;
$ofile=$opt_o;
################################ Reads Input Data ##############################
if ($ifile ne '' && $ofile ne ''){
################# tmp dir #################
$ran= int(rand 10000);
$dir = "/gpsr/standalone/dbpred/temp/dbpred$ran";
$progs="/gpsr/standalone/dbpred/progs";
$models = "/gpsr/models/dbpred";


system "mkdir $dir";
system "chmod 777 $dir";
#################################

system "/gpsr/local/bin/dos2unix -k -n $ifile $dir/seq.unix >/dev/null 2>1";
system "/gpsr/base/bin/fasta2sfasta -i $dir/seq.unix -o $dir/seq.final";
$num_of_seq=`grep -c '>' $dir/seq.final`;
open(FH2,">$dir/ofile.html") or die "$!";
open (SFASTA,"$dir/seq.final");
while ($sfasta = <SFASTA>)
{
                $sfasta =~ /(>\w+) \#\#(\w+)/;
                my $head=$1; $seq=$2;

                    open(SQ_TEMP,">$dir/seq_temp") or die "$!";   # creating single sequence file ie seq_temp
                    print SQ_TEMP "$head\n$seq\n";
                    close SQ_TEMP;
#################
system "cp $dir/seq_temp $dir/glycoep$job.seq";
open(FP4,">$dir/listname");
print FP4 "$dirname\n";
close FP4;
######## method 1 start n-link ########
if ($method == 1)
{

open(SQ_TEST,">$dir/header") or die "$!";   # creating single sequence file ie seq_temp
print SQ_TEST "<tr><td>$head </td></tr>\n";
close SQ_TEST;
###################### Motif Generation ####################
system "/gpsr/base/bin/fasta2sfasta -i $dir/seq_temp -o $dir/seq_temp.sfasta";
system "/gpsr/base/bin/seq2motif -i $dir/seq_temp.sfasta -w 17 -x y -o $dir/temp.mot";
`tail -n+2 $dir/temp.mot > $dir/temp.mot1`;
system "/gpsr/software/new/anaconda3/bin/python $progs/pfeature_aab.py $dir/temp.mot1 $dir/temp.bin";
`perl -pe 's/,\$//g' $dir/temp.bin > $dir/out`;
`grep ">" $dir/seq_temp >$dir/id`;
########################## SVM Prediction ##################
system "/gpsr/software/new/anaconda3/envs/sumeetp/bin/python3 $progs/pred.py $dir/out $models/model_AAB.h5 $dir/out_dl";
system "/usr/bin/Rscript $progs/round1.R $dir/out_dl $dir/pred_val1";
system "cut -f2 -d' ' $dir/pred_val1|tail -n+2  >  $dir/rounded_out";
system "$progs/count_pred_binary_center -p $dir/rounded_out -s $dir/seq_temp.sfasta -o $dir/result -t $thr";
##################### File Processing ###################
`grep "[0-9]" $dir/result >$dir/xx`;
`grep -v ">" $dir/seq_temp >$dir/only_seq`;
system "/gpsr/software/new/anaconda3/bin/python $progs/single.py $dir/only_seq $dir/single_seq";
`sed '1d' $dir/single_seq|cut -b2|sed '\$d' >$dir/singleletter_seq`;
system "cut -f4 $dir/xx >$dir/pred_res";
system "paste -d '\t' $dir/singleletter_seq $dir/pred_res >$dir/seq+pred";
`perl -pe 's/\n//g' $dir/pred_res|perl -pe 's/\$/\n/g' >$dir/pred_abc`;
############################################ For Downloading ###############
`cat $dir/id $dir/only_seq $dir/pred_abc $progs/tail >> $dir/download`;
######################### Deleting Files which are not required ##############
system "rm $dir/out $dir/id $dir/seq_temp.sfasta $dir/temp.mot* $dir/temp.bin $dir/pred_res $dir/pred_abc";
system "rm $dir/xx $dir/pred_val1 $dir/rounded_out $dir/only_seq $dir/result";
system "rm $dir/header $dir/single_seq $dir/singleletter_seq $dir/seq+pred";
} ## Closing  method '1')
####### method 2 start o-link #########        
if ($method == 2)
        {
open(SQ_TEST,">$dir/header") or die "$!";   # creating single sequence file ie seq_temp
print SQ_TEST "<tr><td>$head </td></tr>\n";
close SQ_TEST;

system "/gpsr/base/bin/fasta2sfasta -i $dir/seq_temp -o $dir/seq_temp.sfasta";
system "/gpsr/base/bin/seq2motif -i $dir/seq_temp.sfasta -w 17 -x y -o $dir/temp.mot";
`tail -n+2 $dir/temp.mot > $dir/temp.mot1`;
system "/gpsr/software/new/anaconda3/bin/python $progs/pfeature_pcb.py $dir/temp.mot1 $dir/temp.bin";
`perl -pe 's/,\$//g' $dir/temp.bin > $dir/out`;
`grep ">" $dir/seq_temp >$dir/id`;
########################## SVM Prediction ##################
system "/gpsr/software/new/anaconda3/envs/sumeetp/bin/python3 $progs/pred.py $dir/out $models/model_PCB.h5 $dir/out_dl";
system "/usr/bin/Rscript $progs/round1.R $dir/out_dl $dir/pred_val1";
system "cut -f2 -d' ' $dir/pred_val1|tail -n+2  >  $dir/rounded_out";
system "$progs/count_pred_binary_center -p $dir/rounded_out -s $dir/seq_temp.sfasta -o $dir/result -t $thr";
##################### File Processing ###################
`grep "[0-9]" $dir/result >$dir/xx`;
`grep -v ">" $dir/seq_temp >$dir/only_seq`;
system "/gpsr/software/new/anaconda3/bin/python $progs/single.py $dir/only_seq $dir/single_seq";
`sed '1d' $dir/single_seq|cut -b2|sed '\$d' >$dir/singleletter_seq`;
system "cut -f4 $dir/xx >$dir/pred_res";
system "paste -d '\t' $dir/singleletter_seq $dir/pred_res >$dir/seq+pred";
`perl -pe 's/\n//g' $dir/pred_res|perl -pe 's/\$/\n/g' >$dir/pred_abc`;
############################################ For Downloading ###############
`cat $dir/id $dir/only_seq $dir/pred_abc $progs/tail >> $dir/download`;
######################### Deleting Files which are not required ##############
system "rm $dir/out $dir/id $dir/seq_temp.sfasta $dir/temp.mot* $dir/temp.bin $dir/pred_res $dir/pred_abc";
system "rm $dir/xx $dir/pred_val1 $dir/rounded_out $dir/only_seq $dir/result";
system "rm $dir/header $dir/single_seq $dir/singleletter_seq $dir/seq+pred";
} ##Close method  '2')
if ($method == 3)
        {
open(SQ_TEST,">$dir/header") or die "$!";   # creating single sequence file ie seq_temp
print SQ_TEST "<tr><td>$head </td></tr>\n";
close SQ_TEST;

system "/gpsr/base/bin/fasta2sfasta -i $dir/seq_temp -o $dir/seq_temp.sfasta";
system "/usr/bin/perl $progs/seq2pssm_imp -i $dir/seq_temp -o $dir/temp.smtx -d /gpsr/software/blastpr/data/swissprot -f $dir";
system "/usr/bin/perl $progs/pssm_n1 -i $dir/temp.smtx -o $dir/temp.pssm";
system "/usr/bin/perl $progs/pssm2pat -i $dir/temp.pssm -w 17 -o $dir/temp.pat";
`cat $progs/pssm_header $dir/temp.pat > $dir/temp.pat1`;
`grep ">" $dir/seq_temp >$dir/id`;
########################## SVM Prediction ##################
system "/gpsr/software/new/anaconda3/envs/sumeetp/bin/python3 $progs/pred.py $dir/temp.pat1 $models/model_PSSM.h5 $dir/out_dl";
system "/usr/bin/Rscript $progs/round1.R $dir/out_dl $dir/pred_val1";
system "cut -f2 -d' ' $dir/pred_val1|tail -n+2  >  $dir/rounded_out";
system "$progs/count_pred_binary_center -p $dir/rounded_out -s $dir/seq_temp.sfasta -o $dir/result -t $thr";
##################### File Processing ###################
`grep "[0-9]" $dir/result >$dir/xx`;
`grep -v ">" $dir/seq_temp >$dir/only_seq`;
system "/gpsr/software/new/anaconda3/bin/python $progs/single.py $dir/only_seq $dir/single_seq";
`sed '1d' $dir/single_seq|cut -b2|sed '\$d' >$dir/singleletter_seq`;
system "cut -f4 $dir/xx >$dir/pred_res";
system "paste -d '\t' $dir/singleletter_seq $dir/pred_res >$dir/seq+pred";
`perl -pe 's/\n//g' $dir/pred_res|perl -pe 's/\$/\n/g' >$dir/pred_abc`;
############################################ For Downloading ###############
`cat $dir/id $dir/only_seq $dir/pred_abc $progs/tail >> $dir/download`;
######################### Deleting Files which are not required ##############
system "rm $dir/id $dir/seq_temp.sfasta $dir/pred_res $dir/pred_abc";
system "rm $dir/xx $dir/pred_val1 $dir/rounded_out $dir/only_seq $dir/result";
system "rm $dir/header $dir/single_seq $dir/singleletter_seq $dir/seq+pred";
} ##Close method  '3')

if ($method == 4)
        {
open(SQ_TEST,">$dir/header") or die "$!";   # creating single sequence file ie seq_temp
print SQ_TEST "<tr><td>$head </td></tr>\n";
close SQ_TEST;

system "/gpsr/base/bin/fasta2sfasta -i $dir/seq_temp -o $dir/seq_temp.sfasta";
system "/gpsr/base/bin/seq2motif -i $dir/seq_temp.sfasta -w 17 -x y -o $dir/temp.mot";
`tail -n+2 $dir/temp.mot > $dir/temp.mot1`;
system "/gpsr/software/new/anaconda3/bin/python $progs/pfeature_aab.py $dir/temp.mot1 $dir/temp.bin";
system "/gpsr/software/new/anaconda3/bin/python $progs/pfeature_pcb.py $dir/temp.mot1 $dir/temp.pcb";
system "/usr/bin/perl $progs/seq2pssm_imp -i $dir/seq_temp -o $dir/temp.smtx -d /gpsr/software/blastpr/data/swissprot -f $dir";
system "/usr/bin/perl $progs/pssm_n1 -i $dir/temp.smtx -o $dir/temp.pssm";
system "/usr/bin/perl $progs/pssm2pat -i $dir/temp.pssm -w 17 -o $dir/temp.pat";
`cat $progs/pssm_header $dir/temp.pat > $dir/temp.pat1`;
`perl -pe 's/,\$//g' $dir/temp.bin > $dir/temp.bin1`;
`perl -pe 's/,\$//g' $dir/temp.pcb > $dir/temp.pcb1`;
`grep ">" $dir/seq_temp >$dir/id`;
########################## SVM Prediction ##################
system "/gpsr/software/new/anaconda3/envs/sumeetp/bin/python3 $progs/pred_hy.py $dir/temp.bin1 $dir/temp.pcb1 $dir/temp.pat1 $models/model.h5 $dir/out_dl";
system "/usr/bin/Rscript $progs/round1.R $dir/out_dl $dir/pred_val1";
system "cut -f2 -d' ' $dir/pred_val1|tail -n+2  >  $dir/rounded_out";
system "$progs/count_pred_binary_center -p $dir/rounded_out -s $dir/seq_temp.sfasta -o $dir/result -t $thr";
##################### File Processing ###################
`grep "[0-9]" $dir/result >$dir/xx`;
`grep -v ">" $dir/seq_temp >$dir/only_seq`;
system "/gpsr/software/new/anaconda3/bin/python $progs/single.py $dir/only_seq $dir/single_seq";
`sed '1d' $dir/single_seq|cut -b2|sed '\$d' >$dir/singleletter_seq`;
system "cut -f4 $dir/xx >$dir/pred_res";
system "paste -d '\t' $dir/singleletter_seq $dir/pred_res >$dir/seq+pred";
`perl -pe 's/\n//g' $dir/pred_res|perl -pe 's/\$/\n/g' >$dir/pred_abc`;
############################################ For Downloading ###############
`cat $dir/id $dir/only_seq $dir/pred_abc $progs/tail >> $dir/download`;
######################### Deleting Files which are not required ##############
system "rm $dir/temp.bin1 $dir/temp.pcb1 $dir/temp.pat1 $dir/id $dir/seq_temp.sfasta $dir/temp.mot* $dir/temp.bin $dir/pred_res $dir/pred_abc";
system "rm $dir/xx $dir/pred_val1 $dir/rounded_out $dir/only_seq $dir/result $dir/temp.pcb $dir/temp.pat";
system "rm $dir/header $dir/single_seq $dir/singleletter_seq $dir/seq+pred";
} ##Close method  '4') 



}  ## Closing 'while' each seq loop Reading sequence one by one   
close FH2;

system "cat $progs/head $dir/download >$dir/download.txt";
system "mv $dir/download.txt $ofile";

}else{
    print "Usage:perl dbpred.pl -i fasta_file -t threshold -m method -o output_file\n";
    print "-i\t input file in fasta format\n-t\t threshold\n-m\t method  \n-o\t output result file\n";
    print "\n\tExample: perl dbpred.pl -i example.fasta -t 0.5 -m 4 -o out.dbpred\n\tWhere,\n\t1: Amino acid binary (AAB) profile based model\n\t2:Physico-chemical propeties based  binary (PCB) profile based model\n\t3: Position-Specific Scoring Matrix (PSSM) profile based model\n\t4:Hybrid (AAB+PCB+PSSM) model\n";
    exit;
}

if(-e "1") { `rm 1`;}
if(-e "/gpsr/standalone/dbpred/1") { `rm /gpsr/standalone/dbpred/1`;}
