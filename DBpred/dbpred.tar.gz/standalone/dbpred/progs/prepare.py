import csv
import sys
with open(sys.argv[1],'r') as tsvfile:
    tsvreader = csv.reader(tsvfile, delimiter="\t")
    for line in tsvreader:
        with open (sys.argv[2],'a') as w:
            w.write(('<tr>'+'<td>'+line[0]+'</td>'+'<td>'+line[1]+'</td>'+'<td>'+line[2]+'</td>'+'<td>'+line[3]+'</td>'+'</tr>')+'\n')
