import sys

####### subroutine to pick each line from input file #######
with open(sys.argv[1],'r') as f:
    lines = f.readlines()
    #print(lines)
######################################################
for line in lines:
     score = line.strip()
     #print(type(score))
     with open(sys.argv[2], 'a') as out:
             out.write("<"+"span"+">"+str(score)+"<"+"/"+"span"+">"+"\n")

