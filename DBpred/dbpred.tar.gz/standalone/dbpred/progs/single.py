import sys

infile = open(sys.argv[1]).read()
for line in enumerate(infile):
    with open(sys.argv[2],'a') as w:
        w.write(str(line).replace(',','\n').replace('(','').replace(')','').replace(' ',''))
