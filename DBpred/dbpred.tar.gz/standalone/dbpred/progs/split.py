import sys

####### subroutine to pick each line from input file #######
with open(sys.argv[1],'r') as f1:
    line1 = f1.readlines()
#with open(sys.argv[2],'r') as f2:
#    line2 = f2.read()
#with open(sys.argv[3],'r') as f3:
#    line3 = f3.read()
    #print(line1)
    #print(line2)
    #print(line3)

    n = m = 0
    while m < len(line1):
        m = m+70
        print("".join(line1[n:m]))
        n = m
#with open(sys.argv[4], 'a') as out:
#    out.write('Seq.'+'\t'+line1+'\n'+'Pred'+'\t'+line2+'Prob'+'\t'+line3+"\n"+"\n")

