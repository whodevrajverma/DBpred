import pandas as pd
import numpy as np
import sys
import os
import tensorflow as tf
from keras.models import load_model
def matrix_gen(data_train):
  matrix_input=np.array(data_train)
  matrix_input.shape
  matrix_3d_form_input= np.zeros([len(data_train),1,len(data_train.columns)], dtype=float)
  matrix_3d_form_input.shape
  for i in range(matrix_input.shape[0]):
    row=matrix_input[i]
    matrix_3d_form_input[i]=np.array(row)
  return matrix_3d_form_input
df1 = pd.read_csv(sys.argv[1])
X1 = matrix_gen(df1)
model = load_model(sys.argv[2])
train_predictions_weighted = model.predict(X1,batch_size=2048)
pd.DataFrame(train_predictions_weighted).to_csv(sys.argv[3], index=None, header=False)
