import sys

####### subroutine to pick each line from input file #######
with open(sys.argv[1],'r') as f:
    lines = f.readlines()
#    print(lines)
######################################################
for line in lines:
     score = line.split('\t')
     #print(type(score))
     new = score[1].strip()
     #print(new)
     #print (type(score))
     if new=='+':
         with open(sys.argv[2], 'a') as out:
             out.write("<"+"span "+"style"+"="+"color: blue"+">"+str(score[0])+"<"+"/"+"span"+">"+"\n")
     else:
        with open(sys.argv[2], 'a') as out:
             out.write("<"+"span "+"style"+"="+"color: black"+">"+str(score[0])+"<"+"/"+"span"+">"+"\n")

