import sys

####### subroutine to pick each line from input file #######
with open(sys.argv[1],'r') as f1:
    line1 = f1.read()[:-1]
with open(sys.argv[2],'r') as f2:
    line2 = f2.read()
with open(sys.argv[3],'r') as f3:
    line3 = f3.read()
    #print(line1)
    #print(line2)
    #print(line3)
#for line in lines:
#     score = line.strip()
     #print(type(score))
with open(sys.argv[4], 'a') as out:
    out.write('ID'+'\t'+line1+'Seq.'+'\t'+line2+'\n'+'Pred'+'\t'+line3+"\n"+"\n")

