import csv
import sys
with open(sys.argv[1],'r') as f:
    tsv = f.read()
    with open (sys.argv[2],'a') as w:
        w.write(('<tr>'+'<td>'+tsv+'</td>'+'</tr>'))
