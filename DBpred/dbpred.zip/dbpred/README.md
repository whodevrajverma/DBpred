# DBPred
# Introduction
DBPred is developed for predicting the DNA-interacting residues in the protein using primary sequence information. More information on DNA-interacting residues is available from its web server http://webs.iiitd.edu.in/raghava/dbpred . This page provide information about standalone version of DBPred. Please read/cite DBPred paper for complete information including algorithm behind DBPred.

Models: In this program, four different models have been incorporated for predicting the DNA-interacting residues, based on four different features such as, Amino Acid Binary (AAB) profile, Physico-chemical based binary (PCB) profile, Position-Specific Scoring Matrix (PSSM) profile, and Hybrid (AAB+PCB+PSSM) features. The model is trained on patterns of length 17 generated using protein sequences classified as DNA-interacting and non-interacting.

Modules/Jobs: This program implement four modules (job types); i) Model 1: AAB profile used as input feature
							      ii) Model 2: PCB profile used as input feature
							     iii) Model 3: PSSM profile used as input feature 
							      iv) Model 4: Hybrid of all features (AAB,PSB,PSSM) used as input feature 

Minimum USAGE: Minimum usage is "python dbpred.py -i example_seq.fa" where example_seq.fa is a input fasta file. This will predict the residues in the seqqeunces provided  in fasta format as DNA-interacting and non-interacting. It will use other parameters by default. It will save output in "outfile.csv" in CSV (comma seperated variables).

Full Usage: Following is complete list of all options, you may get these options by "python dbpred.py -h" 

usage: dbpred.py [-h] -i INPUT [-o OUTPUT] [-j {1,2,3,4}] [-t THRESHOLD]
                 [-p PATH]

Please provide following arguments

optional arguments:
  -h, --help            show this help message and exit
  -i INPUT, --input INPUT
                        Input: Protein sequences in FASTA format
  -o OUTPUT, --output OUTPUT
                        Output: File for saving results by default outfile.csv
  -j {1,2,3,4}, --job {1,2,3,4}
                        Feature Type:
                        1: Amino Acid Binary (AAB) profile
                        2: Physico-chemical based binary (PCB) profile
                        3: Position-Specific Scoring Matrix (PSSM) profile
                        4: Hybrid (AAB+PCB+PSSM), by default 1 (AAB)
  -t THRESHOLD, --threshold THRESHOLD
                        Threshold: Value between 0 to 1 by default 0.05
  -p PATH, --path PATH  Path: Please provide the path of python which has all libraries installed

Input File: It allow users to provide input in i) FASTA format (standard) and ii) Simple Format. The program will generate the patterns of length 17 for each sequence. 

Output File: Program will save result in CSV format, in case user do not provide output file name, it will be stored in outfile.csv. In the output file, three lines will be displayed for each sequence, where, first line represents the ID, second row explains the sequence, and third line exhibits the '+' and '-' sign, where '+' corresponds to residues which are involved in DNA-interaction, and '-' represents the residues which are not involved in DNA-interaction.

Threshold: User should provide threshold between 0 and 1, please note score is propotional to the DNA interacting potential of the resiudes..


DBPred Package Files
=======================
It contantain following files, brief descript of these files given below

INSTALLATION  		: Installations instructions

LICENSE       		: License information

README.md     		: This file provide information about this package

prog            	: This folder contains all the models

dbpred.py 		: Main python program 

example_output.txt	: Example output file in csv format for job 1, i.e. AAB based model

example_seq.fa		: Example file contain peptide sequenaces in FASTA format

envfile                 : It is a file which contains the path various tools required to generate PSSM profile
